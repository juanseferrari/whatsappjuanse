module.exports.FORBIDDEN = {code: 403, message: 'Request not trusted. Invalid Smooch Webhook Secret.'};
module.exports.INTERNAL_SERVER_ERROR = {code: 500, message : 'Internal Server Error.'}